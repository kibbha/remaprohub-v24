# ReMaPro Hub V25.9.7

Critical language engine fix: corrected invalid DOM dataset key generation for `aria-label`, which was throwing during the translation pass and aborting the entire localization cycle. Added inline + programmatic language selector binding and versioned the service-worker cache.
