# ReMaPro Hub V25.9.5

Installer fix: the GitHub installer no longer requires the READY ZIP to be committed to the repository. It upgrades the checked-out source in place and validates the result. The deterministic language switching fix from V25.9.4 is retained.
