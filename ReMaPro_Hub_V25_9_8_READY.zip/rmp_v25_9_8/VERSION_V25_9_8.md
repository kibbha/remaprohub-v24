# ReMaPro Hub V25.9.8

Installer verification fix.
