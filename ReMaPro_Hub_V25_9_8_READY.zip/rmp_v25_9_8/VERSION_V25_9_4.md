# ReMaPro Hub V25.9.4

Correctif définitif du changement de langue dans Paramètres.

- Sélection de langue persistée dans localStorage et l’état applicatif.
- URL de redémarrage avec locale explicite pour garantir la prise en compte au boot.
- Double passe de rendu : mise à jour immédiate puis redémarrage propre de l’application.
- Cache Service Worker versionné V25.9.4.
- Onboarding et paramètres utilisent la même préférence de langue.
- versionCode Android : 25904.
