# ReMaPro Hub V25.9.6

Complete runtime language switching repair: dedicated change listeners, render-then-translate ordering, dynamic DOM observer, persistent locale, and localized document handling.
