# Production checklist — V26.0.0

- [x] Source web versionnée 26.0.0
- [x] Manifest versionné 26.0.0
- [x] Service Worker versionné 26.0.0
- [x] Sélecteur de langue sans handler inline
- [x] Persistance de langue
- [x] Override URL `?lang=xx`
- [x] Observer DOM pour les éléments générés
- [x] Installateur sans dépendance à un ZIP externe
- [x] Build Android contrôlé par version
- [ ] Build GitHub Actions réel
- [ ] Installation APK sur appareil réel
- [ ] Test manuel des 8 langues
