# Test report — V26.0.0 clean rebuild

Date: 2026-09-16

## Validations locales

- Source HTML présente: PASS
- JavaScript inline (`node --check`): PASS
- `bash -n native/scripts/prepare-android.sh`: PASS
- `app/manifest.json` version 26.0.0: PASS
- `native/package.json` version 26.0.0: PASS
- Service Worker cache `remaprohub-v26-0-0`: PASS
- Service Worker registration `sw.js?v=26.0.0`: PASS
- Sélecteur `appLanguage` sans `onchange` inline: PASS
- `bindLanguageSelectors()`: PASS
- `startLanguageObserver()`: PASS
- URL locale `?lang=xx`: PASS
- Workflow d'installation indépendant d'un payload ZIP: PASS

## Non exécuté dans cet environnement

- Build Android GitHub Actions réel
- Installation de l'APK sur un appareil Android réel
- Test tactile réel du changement de langue

Ces points doivent être validés après le build GitHub.
