# ReMaPro Hub V26.0.0 — Clean Rebuild

Cette version reprend la base fonctionnelle V25.9.9 et la normalise en V26.0.0.

## Installation GitHub

Le workflow `install-v26-0-0.yml` **ne dépend d'aucun ZIP présent dans le dépôt**. Il reconstruit la version V26.0.0 directement à partir de la source déjà présente dans le dépôt, puis vérifie le résultat avant de pousser le commit.

1. Remplacer le contenu du dépôt par le contenu de ce package.
2. Conserver `app/`, `native/`, `supabase/` et les assets.
3. Dans GitHub Actions, lancer `Install ReMaPro Hub V26.0.0`.
4. Le workflow doit terminer avec toutes les étapes en vert.
5. Lancer ensuite `Android ReMaPro Hub V26.0.0`.

## Langues

FR, EN, DE, IT, ES, PT, NL et ZH. Le sélecteur utilise un gestionnaire JavaScript centralisé, persiste la langue et prend en charge `?lang=xx` au démarrage.

## Android

Node 24, Java 21, Capacitor 8. L'application est configurée en plein écran immersif et le workflow produit un APK debug dans les artifacts GitHub Actions.

## Limite de validation

Les contrôles statiques de la source sont exécutables localement. Le build Android final doit être exécuté par GitHub Actions et l'APK doit ensuite être testé sur l'appareil réel.
