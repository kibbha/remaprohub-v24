# ReMaPro Hub V26.0.0 — Rebuild propre

Cette version est reconstruite comme un package canonique : l’installation ne fait plus de patch incrémental fragile.

## Inclus
- Application ReMaPro Hub issue de la dernière base fonctionnelle V25.9.9.
- Changement de langue centralisé et persistant (FR/EN/DE/IT/ES/PT/NL/ZH).
- Sélecteurs de langue sans `onchange` inline, binding JS unique et observer pour le DOM dynamique.
- Paramètre `?lang=` prioritaire au démarrage.
- Service worker versionné `remaprohub-v26-0-0`.
- Métadonnées web et Android alignées sur `26.0.0`.
- Pipeline Android propre avec Capacitor 8, Node 24 et Java 21.
- Fullscreen immersif conservé.
- Modules métier et accès développeur local conservés.

## Méthode
Le dépôt doit recevoir le package complet. Le workflow d'installation vérifie et committe la source canonique ; il ne tente plus de deviner la version précédente ni de modifier une ancienne base avec une série de regex fragiles.
