# ReMaPro Hub V24.0.0 — Clean Foundation

ReMaPro Hub est un copilote mobile pour le management de la restauration : pilotage, organisation, actions, stock, finance, HACCP, équipe, RH, achats, recettes et aide à la décision.

## Architecture
- `app/` : application web autonome, sans dépendance CDN.
- `native/` : Capacitor Android généré au build.
- `supabase/functions/remapro-ai/` : endpoint IA sécurisé, clé OpenAI uniquement côté serveur.
- `.github/workflows/` : installation et build Android.

## Principes V24
- Projet neuf, aucune dépendance aux anciens fichiers ReMaPro.
- Accueil volontairement minimal : 4 indicateurs, alertes, priorités, accès par icônes.
- Toutes les fonctions spécialisées restent accessibles via « Plus ».
- Données locales sous `remaprohub-data-v24`.
- Caméra produit et préparation pour identification Vision sécurisée.
- PWA offline-first.
- Android généré par Capacitor au moment du build.

## Installation
1. Déposer `ReMaPro_Hub_V24_0_READY.zip` à la racine du nouveau dépôt.
2. Déposer les deux workflows dans `.github/workflows/`.
3. Lancer `Install V24.0.0`.
4. Lancer `Android V24.0.0`.
5. Récupérer l'APK dans les artefacts GitHub Actions.

La génération Android est volontairement effectuée à partir de zéro : aucun dossier `android/` historique n'est embarqué.
