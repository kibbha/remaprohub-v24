# ReMaPro Hub V24.0.0

Refonte propre et autonome destinée à éliminer les dépendances historiques et les erreurs de packaging des versions précédentes.
