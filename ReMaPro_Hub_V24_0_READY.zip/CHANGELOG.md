# Changelog

## V24.0.0
- Nouvelle base applicative autonome.
- Accueil allégé et navigation par modules.
- Manager Copilot, actions, stock, finance et journal manager.
- Caméra produit et préparation Vision/code-barres.
- PWA offline-first et icônes dédiées.
- Android généré à partir de zéro par Capacitor.
- Workflows strictement synchronisés.
