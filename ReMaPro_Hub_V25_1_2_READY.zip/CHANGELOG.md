# CHANGELOG — ReMaPro Hub

## V25.1.2 — 15 septembre 2026
- Correction complète du changement de langue après rendu dynamique.
- Normalisation des traductions pour que les contenus français et anglais générés par les modules puissent être reconnus et convertis dans la langue active.
- Correction des dictionnaires allemand et italien qui étaient mal structurés dans V25.1.1.
- Renforcement des traductions de navigation, statuts, actions et états vides.
- Ajout d’un onglet **Aide & formation** accessible depuis la navigation et le menu Plus.
- Guide pratique : démarrage, stock/achats, recettes/marge, HACCP, équipe/RH, documents, Copilot, stock par photo et méthode de pilotage.
- Les boutons d’aide depuis Paramètres > À propos ouvrent désormais directement le centre d’aide.
- Version web, PWA et Android synchronisée en 25.1.2.

## V25.1.1

- Correctif du workflow d’installation : le tableau de bord `view active` est maintenant correctement reconnu par l’audit des vues.
- Audit navigation/vues renforcé : 29 entrées de navigation et 29 vues validées.
- Version web/native/service worker synchronisée en 25.1.1.
- Aucun changement de la base visuelle Signature.

# CHANGELOG ReMaPro Hub

## V25.1.0
- Base visuelle V25 conservée volontairement.
- Réintégration et raccordement des fonctions métier principales.
- Navigation complète et accès mobile via Plus.
- Stock : CRUD, catégories, seuils, mouvements et capture photo.
- Recettes : ingrédients, coût matière, portions et food cost.
- HACCP : contrôles, seuils et actions correctives.
- Équipe, tâches, clients, POS et réservations : création, modification, suppression et suivi.
- Finance : CA journalier, moyens de paiement, dépenses, résultat et contrôle caisse.
- Achats, fournisseurs, traçabilité et pertes : CRUD complet.
- Documents professionnels : PDF, téléchargement, remplissage, sauvegarde, modification et impression.
- RH : formulaires et calculateurs opérationnels.
- Nouveaux modules : maintenance, briefing, passation, incidents, KPI hebdomadaire et échéances conformité.
- Copilot local/cloud et analyse photo stock IA optionnelle.
- Export/import et stockage local conservés.
- Android : workflow propre, TypeScript explicite et validation du manifeste avant Gradle.
