# CHANGELOG ReMaPro Hub

## V25.1.0
- Base visuelle V25 conservée volontairement.
- Réintégration et raccordement des fonctions métier principales.
- Navigation complète et accès mobile via Plus.
- Stock : CRUD, catégories, seuils, mouvements et capture photo.
- Recettes : ingrédients, coût matière, portions et food cost.
- HACCP : contrôles, seuils et actions correctives.
- Équipe, tâches, clients, POS et réservations : création, modification, suppression et suivi.
- Finance : CA journalier, moyens de paiement, dépenses, résultat et contrôle caisse.
- Achats, fournisseurs, traçabilité et pertes : CRUD complet.
- Documents professionnels : PDF, téléchargement, remplissage, sauvegarde, modification et impression.
- RH : formulaires et calculateurs opérationnels.
- Nouveaux modules : maintenance, briefing, passation, incidents, KPI hebdomadaire et échéances conformité.
- Copilot local/cloud et analyse photo stock IA optionnelle.
- Export/import et stockage local conservés.
- Android : workflow propre, TypeScript explicite et validation du manifeste avant Gradle.
