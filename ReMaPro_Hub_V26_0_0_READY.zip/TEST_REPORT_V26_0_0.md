# Test Report V26.0.0

## Validation statique locale
- JavaScript inline : PASS (`node --check`)
- JSON manifest : PASS
- JSON package Android : PASS
- Bash prepare-android : PASS (`bash -n`)
- Version APP_VERSION : 26.0.0
- Service worker cache : remaprohub-v26-0-0
- Sélecteur langue sans onchange inline : PASS
- `bindLanguageSelectors()` : PASS
- `startLanguageObserver()` : PASS
- URL `?lang=` : PASS

## Limite
Un APK ne peut pas être exécuté ici sur un appareil Android réel. Le pipeline GitHub Actions reste donc la validation finale du toolchain Android.
