# ReMaPro Hub V26.0.0 — Rebuild

Package canonique reconstruit à partir de la dernière base V25.9.9.

## Fichiers principaux
- `app/index.html` — application complète
- `app/manifest.json` — PWA
- `app/sw.js` — cache V26.0.0
- `native/` — projet Capacitor source
- `.github/workflows/install-v26-0-0.yml` — vérification/installation
- `.github/workflows/build-android-v26-0-0.yml` — build APK

## Déploiement
1. Remplacer le contenu du dépôt par le contenu de ce package.
2. Lancer `Install ReMaPro Hub V26.0.0`.
3. Quand le workflow est vert, lancer `Android ReMaPro Hub V26.0.0`.
4. Récupérer l'APK dans l'artifact `ReMaPro-Hub-V26.0.0-debug-apk`.

Le workflow d'installation ne fait plus de patch incrémental dépendant d'une ancienne version : il vérifie une source canonique complète.
