# Test report V25.5.0

- JavaScript syntax: PASS
- Bash syntax: PASS
- Manifest JSON: PASS
- PWA display: fullscreen
- display_override: fullscreen, standalone
- Android immersive code: status + navigation bars hidden
- Re-application on resume/focus: PASS
- Mobile bottom navigation safe-area spacing: PASS
- Workflow Java cache ordering: cache is enabled only after fresh Android project creation

Note: a physical Android build/runtime test still has to be executed by GitHub Actions/device.
