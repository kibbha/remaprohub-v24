# ReMaPro Hub V25.5.0

Correctif plein écran mobile Android/PWA et navigation interne.
