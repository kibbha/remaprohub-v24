import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.remaprohub.app',
  appName: 'ReMaPro Hub',
  webDir: '../app'
};
export default config;
